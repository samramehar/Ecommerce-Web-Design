# E-commerce Website

A modern, responsive e-commerce website built with HTML5, CSS3, and JavaScript. This project features a complete online shopping experience with multiple pages and interactive functionality.

## 🚀 Features

### Pages
- **Homepage** - Landing page with hero section, deals, product categories, and newsletter signup
- **Product Listing** - Grid/list view with advanced filtering and sorting
- **Product Details** - Detailed product view with image gallery, specifications, and supplier info
- **Shopping Cart** - Cart management with quantity updates, saved items, and checkout

### Interactive Features
- **Search Bar** - Functional search with category dropdown
- **Product Filters** - Brand, price range, condition, and rating filters
- **View Toggle** - Switch between grid and list views
- **Image Gallery** - Product image thumbnails with main image display
- **Cart Management** - Add/remove items, quantity updates, save for later
- **Wishlist** - Add/remove items from wishlist
- **Countdown Timer** - Live countdown for deals and offers
- **Newsletter Signup** - Email subscription with validation
- **Responsive Design** - Mobile-friendly layout

## 📁 Project Structure

```
ecommerce-website/
├── index.html              # Homepage
├── products.html           # Product listing page
├── product-details.html    # Product details page
├── cart.html              # Shopping cart page
├── css/
│   ├── style.css          # Global styles and variables
│   ├── header.css         # Header-specific styles
│   ├── footer.css         # Footer-specific styles
│   ├── home.css           # Homepage styles
│   ├── products.css       # Product listing styles
│   ├── product-details.css # Product details styles
│   └── cart.css           # Shopping cart styles
├── js/
│   ├── main.js            # Main JavaScript functionality
│   ├── products.js        # Product listing functionality
│   ├── product-details.js # Product details functionality
│   └── cart.js            # Shopping cart functionality
├── images/                # Product and UI images
└── README.md             # Project documentation
```

## 🎨 Design System

### Colors
- **Primary Blue**: `#0066cc` - Main brand color
- **Secondary Orange**: `#ff6b35` - Accent color for CTAs
- **Accent Teal**: `#00d4aa` - Highlight color
- **Text Dark**: `#1c1c1c` - Primary text
- **Text Light**: `#8b96a5` - Secondary text
- **Border**: `#e3e8ef` - Borders and dividers

### Typography
- **Font Family**: Segoe UI, Tahoma, Geneva, Verdana, sans-serif
- **Font Weights**: 400 (regular), 500 (medium), 600 (semibold), 700 (bold)

### Components
- **Buttons**: Primary, outline, and secondary variants
- **Cards**: Product cards with hover effects
- **Forms**: Input fields with focus states
- **Navigation**: Sticky header with dropdown menus

## 🛠️ Technologies Used

- **HTML5** - Semantic markup and structure
- **CSS3** - Modern styling with CSS Grid, Flexbox, and custom properties
- **JavaScript (ES6+)** - Interactive functionality and DOM manipulation
- **Font Awesome** - Icon library for UI elements

## 🚀 Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Local web server (optional, for development)

### Installation
1. Clone or download the project files
2. Open `index.html` in your web browser
3. Navigate through the different pages to explore the functionality

### Development Setup
For the best development experience:
1. Use a local web server (e.g., Live Server in VS Code)
2. Open the project in a code editor
3. Make changes to HTML, CSS, or JavaScript files
4. Refresh the browser to see updates

## 📱 Responsive Design

The website is fully responsive and optimized for:
- **Desktop** (1200px+) - Full layout with all features
- **Tablet** (768px - 1199px) - Adjusted grid layouts
- **Mobile** (320px - 767px) - Single column layouts

## 🔧 Customization

### Adding New Products
1. Update the `productsData` array in `js/products.js`
2. Add product images to the `images/` folder
3. Update product cards in HTML files

### Modifying Styles
1. Edit CSS variables in `css/style.css` for global changes
2. Modify specific page styles in their respective CSS files
3. Use the existing design system for consistency

### Adding New Features
1. Create new JavaScript functions in appropriate files
2. Add corresponding HTML elements
3. Style new components following the design system

## 🎯 Key Features Explained

### Product Filtering
- **Category Filter**: Filter by product categories
- **Brand Filter**: Filter by specific brands
- **Price Range**: Set minimum and maximum prices
- **Condition Filter**: Filter by product condition
- **Rating Filter**: Filter by star ratings

### Shopping Cart
- **Quantity Updates**: Change item quantities with automatic price calculation
- **Remove Items**: Remove individual items or clear entire cart
- **Save for Later**: Move items to saved items section
- **Coupon Codes**: Apply discount codes (SAVE10, DISCOUNT20, WELCOME15)
- **Order Summary**: Real-time calculation of subtotal, tax, and total

### Product Details
- **Image Gallery**: Multiple product images with thumbnail navigation
- **Price Tiers**: Quantity-based pricing
- **Supplier Information**: Seller details and verification status
- **Product Specifications**: Detailed product information
- **Related Products**: Product recommendations

## 🐛 Known Issues

- Image placeholders are used for demonstration (replace with actual product images)
- Payment processing is simulated (integrate with real payment gateway)
- Search functionality shows alerts (connect to backend search API)

## 🔮 Future Enhancements

- **User Authentication**: Login/register functionality
- **Product Reviews**: Customer review system
- **Advanced Search**: Search suggestions and filters
- **Payment Integration**: Real payment processing
- **Inventory Management**: Stock tracking
- **Order Tracking**: Order status and tracking
- **Multi-language Support**: Internationalization
- **PWA Features**: Offline support and app-like experience

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🤝 Contributing

1. Fork the project
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📞 Support

For questions or support, please open an issue in the project repository.

---

**Note**: This is a frontend demonstration project. For production use, integrate with a backend API and database for full e-commerce functionality.